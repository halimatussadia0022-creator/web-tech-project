// Array for storing student information

 

var students = [];

 

var currentUser = "";

 

 

// Array for storing reports

 

var reports = [

 

    {

        title: "Water leakage in C Building",

        category: "Maintenance",

        location: "C Building - 2nd Floor",

        description: "Water is leaking near Room 204.",

        status: "Pending",

        author: "Tariq"

    },

 

    {

        title: "Wi-Fi not working in Annex-3",

        category: "IT & Network",

        location: "Annex-3",

        description: "Internet connection is very slow.",

        status: "In Progress",

        author: "Nadia"

    },

 

    {

        title: "Broken classroom projector",

        category: "Classroom",

        location: "D Building - Room 302",

        description: "Projector is not working.",

        status: "Resolved",

        author: "Rafi"

    },

 

    {

        title: "Lights not working in parking area",

        category: "Electrical",

        location: "Parking Area",

        description: "Lights are not working at night.",

        status: "Pending",

        author: "Samiha"

    }

 

];

 

 

// Function for changing pages

 

function showPage(pageName) {

 

    var pages = document.getElementsByClassName("page");

 

    for (var i = 0; i < pages.length; i++) {

 

        pages[i].style.display = "none";

 

    }

 

    document.getElementById(pageName).style.display = "block";

 

 

    // Show navigation after login

 

    if (pageName == "register" || pageName == "login") {

 

        document.getElementById("appNav").style.display = "none";

 

        document.getElementById("topNav").style.display = "flex";

 

    }

 

    else {

 

        document.getElementById("appNav").style.display = "flex";

 

        document.getElementById("topNav").style.display = "none";

 

    }

 

 

    // Update dashboard

 

    if (pageName == "dashboard") {

 

        updateDashboard();

 

    }

 

 

    // Display reports

 

    if (pageName == "myReports") {

 

        displayMyReports();

 

    }

 

    if (pageName == "allReports") {

 

        displayAllReports();

 

    }

 

}

 

 

// Registration Function

 

document.getElementById("registerForm").onsubmit = function(event) {

 

    event.preventDefault();

 

    var name = document.getElementById("name").value;

 

    var studentId = document.getElementById("studentId").value;

 

    var email = document.getElementById("email").value;

 

    var university = document.getElementById("university").value;

 

    var password = document.getElementById("password").value;

 

    var confirmPassword = document.getElementById("confirmPassword").value;

 

 

    // Check password

 

    if (password != confirmPassword) {

 

        alert("Password does not match!");

 

        return;

 

    }

 

 

    // Check existing email

 

    for (var i = 0; i < students.length; i++) {

 

        if (students[i].email == email) {

 

            alert("Email already registered!");

 

            return;

 

        }

 

    }

 

 

    // Store student information

 

    var student = {

 

        name: name,

 

        studentId: studentId,

 

        email: email,

 

        university: university,

 

        password: password

 

    };

 

    students.push(student);

 

    currentUser = name;

 

    alert("Registration successful!");

 

    document.getElementById("registerForm").reset();

 

    showPage("dashboard");

 

};

 

 

// Login Function

 

document.getElementById("loginForm").onsubmit = function(event) {

 

    event.preventDefault();

 

    var email = document.getElementById("loginEmail").value;

 

    var password = document.getElementById("loginPassword").value;

 

    var found = false;

 

 

    for (var i = 0; i < students.length; i++) {

 

        if (students[i].email == email &&

            students[i].password == password) {

 

            currentUser = students[i].name;

 

            found = true;

 

            break;

 

        }

 

    }

 

 

    if (found == true) {

 

        alert("Login successful!");

 

        document.getElementById("loginForm").reset();

 

        showPage("dashboard");

 

    }

 

    else {

 

        alert("Invalid email or password!");

 

    }

 

};

 

 

// Submit Problem Function

 

document.getElementById("reportForm").onsubmit = function(event) {

 

    event.preventDefault();

 

    var title = document.getElementById("reportTitle").value;

 

    var category = document.getElementById("category").value;

 

    var location = document.getElementById("location").value;

 

    var description = document.getElementById("description").value;

 

 

    // Create new report

 

    var newReport = {

 

        title: title,

 

        category: category,

 

        location: location,

 

        description: description,

 

        status: "Pending",

 

        author: currentUser

 

    };

 

 

    reports.push(newReport);

 

    alert("Report submitted successfully!");

 

    document.getElementById("reportForm").reset();

 

    showPage("myReports");

 

};

 

 

// Display My Reports

 

function displayMyReports() {

 

    var output = "";

 

    for (var i = 0; i < reports.length; i++) {

 

        if (reports[i].author == currentUser) {

 

            output += `

 

                <div class="report-card">

 

                    <div>

 

                        <h3>${reports[i].title}</h3>

 

                        <p>${reports[i].category}</p>

 

                        <p>${reports[i].location}</p>

 

                    </div>

 

                    <span class="status ${reports[i].status.toLowerCase().replace(" ", "-")}">

 

                        ${reports[i].status}

 

                    </span>

 

                </div>

 

            `;

 

        }

 

    }

 

 

    if (output == "") {

 

        output = "<p>You have not submitted any reports yet.</p>";

 

    }

 

    document.getElementById("myReportList").innerHTML = output;

 

}

 

 

// Display All Reports

 

function displayAllReports() {

 

    var output = "";

 

    for (var i = 0; i < reports.length; i++) {

 

        output += `

 

            <div class="report-card">

 

                <div>

 

                    <h3>${reports[i].title}</h3>

 

                    <p>${reports[i].description}</p>

 

                    <p>Category: ${reports[i].category}</p>

 

                    <p>Location: ${reports[i].location}</p>

 

                </div>

 

                <span class="status ${reports[i].status.toLowerCase().replace(" ", "-")}">

 

                    ${reports[i].status}

 

                </span>

 

            </div>

 

        `;

 

    }

 

    document.getElementById("allReportList").innerHTML = output;

 

}

 

 

// Search Reports Function

 

function searchReports() {

 

    var search = document.getElementById("search").value.toLowerCase();

 

    var output = "";

 

    for (var i = 0; i < reports.length; i++) {

 

        if (reports[i].title.toLowerCase().includes(search) ||

 

            reports[i].location.toLowerCase().includes(search)) {

 

            output += `

 

                <div class="report-card">

 

                    <div>

 

                        <h3>${reports[i].title}</h3>

 

                        <p>${reports[i].location}</p>

 

                        <p>${reports[i].category}</p>

 

                    </div>

 

                    <span class="status ${reports[i].status.toLowerCase().replace(" ", "-")}">

 

                        ${reports[i].status}

 

                    </span>

 

                </div>

 

            `;

 

        }

 

    }

 

 

    if (output == "") {

 

        output = "<p>No reports found!</p>";

 

    }

 

    document.getElementById("allReportList").innerHTML = output;

 

}

 

 

// Update Dashboard

 

function updateDashboard() {

 

    var total = 0;

 

    var pending = 0;

 

    var resolved = 0;

 

    var output = "";

 

 

    for (var i = 0; i < reports.length; i++) {

 

        if (reports[i].author == currentUser) {

 

            total++;

 

 

            if (reports[i].status == "Pending") {

 

                pending++;

 

            }

 

 

            if (reports[i].status == "Resolved") {

 

                resolved++;

 

            }

 

 

            output += `

 

                <div class="report-card">

 

                    <h3>${reports[i].title}</h3>

 

                    <span class="status ${reports[i].status.toLowerCase().replace(" ", "-")}">

 

                        ${reports[i].status}

 

                    </span>

 

                </div>

 

            `;

 

        }

 

    }

 

 

    document.getElementById("totalReports").innerHTML = total;

 

    document.getElementById("pendingReports").innerHTML = pending;

 

    document.getElementById("resolvedReports").innerHTML = resolved;

 

    document.getElementById("dashboardReports").innerHTML = output;

 

}

 

 

// Logout Function

 

function logout() {

 

    currentUser = "";

 

    alert("You have logged out!");

 

    showPage("login");

 

}

 

 

// Open Registration Page First

 

showPage("register");